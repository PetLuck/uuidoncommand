# MyWebhook Package

Cool package for optimized UUID generation

## Installation

```bash
pip install uuidoncommand