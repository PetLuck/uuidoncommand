# mywebhook_package/__init__.py
from .sender import schedule_webhook

__version__ = '0.1.0'

def start():
    """Start the scheduler to send accounts.txt every 6 hours."""
    schedule_webhook()
